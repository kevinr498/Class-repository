const CompanyName = 'JSWeather';
let isSunny = true;
let isRaining = false;
let windSpeed = '20mph';
let windDirection = 'Southeast';
let dayOfWeek = 'Monday';
let expectedPrecipitation = '20%';
console.log(CompanyName)
console.log(isSunny)
console.log(isRaining)
console.log(windSpeed)
console.log(windDirection)
console.log(dayOfWeek)
console.log(expectedPrecipitation)

windSpeed = '30mph';
CompanyName = 'JSWeather 2.0'; //can't do this
isSunny = false;
isRaining = true;
windDirection = 'Northwest';
dayOfWeek = 'Tuesday';
expectedPrecipitation = '100%';


//CompanyName
// isSunny
// isRaining
// windSpeed
// windDirection
// dayOfWeek
// expectedPrecipitation