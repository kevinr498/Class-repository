CREATE TABLE pdfs (
	id SERIAL PRIMARY KEY,
  name varchar(255) NOT NULL
);