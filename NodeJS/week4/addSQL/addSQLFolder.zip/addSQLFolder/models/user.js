class inputs {
  constructor(ids, type, color, quantity) {
    this.ids = ids;
    this.type = type;
    this.color = color;
    this.quantity = quantity;
  }
}

module.exports = inputs;
