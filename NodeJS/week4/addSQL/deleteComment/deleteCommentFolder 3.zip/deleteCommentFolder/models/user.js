class User {
  constructor(id, username, password, haircolor) {
    this.id = id;
    this.username = username;
    this.password = password;
    this.haircolor = haircolor;
  }
}

module.exports = User;
