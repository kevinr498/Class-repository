class Comment {
  constructor(comment_text, user_id) {
    this.comment_text = comment_text;
    this.user_id = user_id;
  }
}

module.exports = Comment;
