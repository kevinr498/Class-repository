class User {
  constructor(username, password, haircolor) {
    this.username = username;
    this.password = password;
    this.haircolor = haircolor;
  }
}

module.exports = User;
