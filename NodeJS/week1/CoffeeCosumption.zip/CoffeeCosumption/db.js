export const caffeine_consumption_amount = [
  {
    date: 1,
    bed_time: "6pm",
    caffeine_consumption: "6 cups of cofee",
    quality_of_sleep: "bad",
  },
  {
    date: 2,
    bed_time: "6:30pm",
    caffeine_consumption: "1 cups of cofee",
    quality_of_sleep: "great",
  },
  {
    date: 3,
    bed_time: "7pm",
    caffeine_consumption: "3 cups of cofee",
    quality_of_sleep: "okay",
  },
];
