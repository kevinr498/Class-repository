export const crudRoutes = [
  {
    id: 1,
    type: "Bar",
    color: "Copper",
    quantity: 103,
  },
  {
    id: 2,
    type: "Block",
    color: "Silver",
    quantity: 76,
  },
  {
    id: 3,
    type: "Ore",
    color: "Gold",
    quantity: 24,
  },
];
